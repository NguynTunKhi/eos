#!/usr/bin/env python
# -*- coding: utf8 -*-
# Plural-Forms for ar (Arabic)
